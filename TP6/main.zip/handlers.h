void gordon_handler(int signum);
void gordon_child_handler(int signum, siginfo_t *siginfo, void* unused);
void set_masks();