char * cd_gordon(char * to);
int exit_gordon();
void config_background_task();